# 3105 Build Preparation

This copy has a unique bundle identifier (`com.nextra.threeoneosfive`) so it does not intentionally reuse an Apple system bundle identifier.

## Build
1. Open `ThreeOneOSFive.xcodeproj` in Xcode on macOS.
2. Select the `ThreeOneOSFive`/`3105` target.
3. In **Signing & Capabilities**, select your Apple Developer Team and keep **Automatically manage signing** enabled.
4. Select a connected device or a generic iOS device destination.
5. Product → Build.
6. To export an IPA, Product → Archive, then use Organizer → Distribute App.

This environment cannot run Xcode, so the project was not compiled here. Any remaining source-level errors will need to be resolved in Xcode.
