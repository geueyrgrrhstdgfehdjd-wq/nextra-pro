import SwiftUI
import UIKit

@main
struct NextraProApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var licenseSession = LicenseSession()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @Environment(\.scenePhase) private var scenePhase

    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .english
    }

    var body: some Scene {
        WindowGroup {
            Group {
                if licenseSession.isAuthorized {
                    ContentView()
                        .environmentObject(appState)
                        .environmentObject(licenseSession)
                        .environmentObject(patchDraftCoordinator)
                        .environmentObject(fileOperationCoordinator)
                        .environment(\.appLanguage, language)
                        .environment(\.locale, language.locale)
                } else {
                    LicenseGateView()
                        .environmentObject(licenseSession)
                        .environment(\.appLanguage, language)
                        .environment(\.locale, language.locale)
                }
            }
            .onAppear {
                licenseSession.startValidation()
                if licenseSession.isAuthorized {
                    appState.detectSupport()
                }
            }
            .onChange(of: licenseSession.isAuthorized) { authorized in
                if authorized {
                    appState.detectSupport()
                }
            }
            .onChange(of: scenePhase) { phase in
                guard phase == .active else { return }
                licenseSession.revalidateStoredKey()
            }
            .onOpenURL { url in
                guard licenseSession.isAuthorized else { return }
                patchDraftCoordinator.presentImport(url)
            }
        }
    }
}

@MainActor
final class LicenseSession: ObservableObject {
    @Published private(set) var isAuthorized = false
    @Published private(set) var isChecking = true
    @Published var errorMessage: String?
    @Published private(set) var expiresAt: String?

    private let storageKey = "nextra.pro.license.key"
    private var validationTask: Task<Void, Never>?

    var storedKey: String {
        UserDefaults.standard.string(forKey: storageKey) ?? ""
    }

    func startValidation() {
        guard !storedKey.isEmpty else {
            isChecking = false
            isAuthorized = false
            return
        }
        revalidateStoredKey()
    }

    func revalidateStoredKey() {
        guard !storedKey.isEmpty else {
            isChecking = false
            isAuthorized = false
            return
        }
        validate(storedKey, persistOnSuccess: false)
    }

    func submit(_ key: String) {
        let normalized = key.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !normalized.isEmpty else {
            errorMessage = "กรุณาใส่คีย์"
            return
        }
        validate(normalized, persistOnSuccess: true)
    }

    func logout() {
        validationTask?.cancel()
        UserDefaults.standard.removeObject(forKey: storageKey)
        expiresAt = nil
        errorMessage = nil
        isAuthorized = false
        isChecking = false
    }

    private func validate(_ key: String, persistOnSuccess: Bool) {
        validationTask?.cancel()
        isChecking = true
        errorMessage = nil

        validationTask = Task {
            do {
                let response = try await LicenseService.validate(key: key)
                guard !Task.isCancelled else { return }
                if response.valid {
                    if persistOnSuccess {
                        UserDefaults.standard.set(key, forKey: storageKey)
                    }
                    expiresAt = response.expiresAt
                    isAuthorized = true
                    errorMessage = nil
                } else {
                    if persistOnSuccess {
                        UserDefaults.standard.removeObject(forKey: storageKey)
                    }
                    expiresAt = nil
                    isAuthorized = false
                    errorMessage = response.message ?? "คีย์ไม่ถูกต้องหรือหมดอายุ"
                }
            } catch {
                guard !Task.isCancelled else { return }
                isAuthorized = false
                errorMessage = "เชื่อมต่อระบบคีย์ไม่ได้ กรุณาตรวจสอบ URL หลังบ้านและอินเทอร์เน็ต"
            }
            isChecking = false
        }
    }
}

private struct LicenseAPIResponse: Decodable {
    let valid: Bool
    let message: String?
    let expiresAt: String?

    enum CodingKeys: String, CodingKey {
        case valid, message
        case expiresAt = "expires_at"
    }
}

enum LicenseService {
    // เปลี่ยน URL นี้เป็น URL ที่ติดตั้ง NEXTRA PRO Admin เช่น https://example.com/api.php
    static let endpoint = URL(string: "https://nextrapro.onrender.com/api/validate-key")!

    static func validate(key: String) async throws -> LicenseAPIResponse {
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.timeoutInterval = 15
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "action": "validate_key",
            "key": key,
            "app": "NEXTRA PRO"
        ])

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw URLError(.badServerResponse)
        }

        // The API intentionally returns {valid:false,...} with 4xx for invalid/expired keys.
        // Decode that response so the app can show the backend's actual message.
        if let decoded = try? JSONDecoder().decode(LicenseAPIResponse.self, from: data) {
            return decoded
        }
        guard (200..<300).contains(http.statusCode) else {
            throw URLError(.badServerResponse)
        }
        throw URLError(.cannotParseResponse)
    }
}

@MainActor
final class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?
    @Published var kernelExploitRunning = false

    private var autoRunAttempted = false

    var kernelExploitApplicable: Bool {
        KernelExploit.isApplicable(
            major: AppInfo.versionTuple.major,
            minor: AppInfo.versionTuple.minor,
            patch: AppInfo.versionTuple.patch,
            build: AppInfo.osBuild
        )
    }

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
            return
        }

        let applicable = KernelExploit.isApplicable(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
        guard applicable else { return }

        refreshKernelExploitStatus()
        maybeAutoRunKernelExploit()
    }

    private func maybeAutoRunKernelExploit() {
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed,
              !autoRunAttempted else { return }
        autoRunAttempted = true
        runKernelExploitIfNeeded()
    }

    private func refreshKernelExploitStatus() {
        guard !kernelExploitRunning else { return }
        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                if !exploitStatus.isSuccess {
                    exploitStatus = .success(method: "kexploit")
                }
            } else if exploitStatus.isSuccess {
                exploitStatus = .notStarted
            }
        }
    }

    func runKernelExploitIfNeeded() {
        refreshKernelExploitStatus()
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed else { return }
        kernelExploitRunning = true
        exploitStatus = .notStarted
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = KernelExploit.run()
            DispatchQueue.main.async {
                self.kernelExploitRunning = false
                if ok {
                    self.exploitStatus = .success(method: "kexploit")
                } else {
                    self.exploitStatus = .failed(method: "kexploit", code: -1)
                }
            }
        }
    }
}

private struct LicenseGateView: View {
    @EnvironmentObject private var session: LicenseSession
    @State private var key = ""

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.01, green: 0.02, blue: 0.06), Color.black],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack(spacing: 22) {
                Image("NextraLogo")
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 300, maxHeight: 220)
                    .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))

                VStack(spacing: 7) {
                    Text("NEXTRA PRO")
                        .font(.system(size: 30, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    Text("ใส่คีย์เพื่อเข้าใช้งาน")
                        .font(.headline)
                        .foregroundStyle(.secondary)
                }

                VStack(spacing: 12) {
                    TextField("NEXTRA PRO KEY", text: $key)
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                        .textFieldStyle(.plain)
                        .padding(15)
                        .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))
                        .overlay(RoundedRectangle(cornerRadius: 14).stroke(AppTheme.accent.opacity(0.55), lineWidth: 1))
                        .foregroundStyle(.white)

                    if let error = session.errorMessage {
                        Text(error)
                            .font(.footnote)
                            .foregroundStyle(.red)
                            .multilineTextAlignment(.center)
                    }

                    Button {
                        session.submit(key)
                    } label: {
                        HStack {
                            if session.isChecking { ProgressView().tint(.white) }
                            Text(session.isChecking ? "กำลังตรวจสอบ…" : "เข้าสู่ NEXTRA PRO")
                                .fontWeight(.bold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(.white)
                    .background(AppTheme.accent, in: RoundedRectangle(cornerRadius: 14))
                    .disabled(session.isChecking || key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
                .frame(maxWidth: 420)

                Text("คีย์จะต้องมีอยู่ในระบบหลังบ้าน NEXTRA PRO และยังไม่หมดอายุ")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: 360)
            }
            .padding(24)
        }
    }
}
