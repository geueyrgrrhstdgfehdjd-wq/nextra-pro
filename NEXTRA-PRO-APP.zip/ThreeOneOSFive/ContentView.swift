import SwiftUI
import UIKit

struct ContentView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @State private var tabNavigation: AppTabNavigationState
    @AppStorage(FeatureVisibility.cleanerStorageKey) private var cleanerEnabled = true
    @AppStorage(FeatureVisibility.wallpapersStorageKey) private var wallpapersEnabled = true

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab: Int
        if arguments.contains("--simulate-files-tab") {
            initialTab = 1
        } else if arguments.contains("--simulate-patch-tab") {
            initialTab = 2
        } else if arguments.contains("--simulate-cleaner-tab") {
            initialTab = 3
        } else if arguments.contains("--simulate-wallpaper-tab") {
            initialTab = 4
        } else {
            initialTab = 0
        }
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: initialTab))
#else
        _tabNavigation = State(initialValue: AppTabNavigationState())
#endif
    }

    var body: some View {
        Group {
            if horizontalSizeClass == .regular {
                regularLayout
            } else {
                compactLayout
            }
        }
        .tint(AppTheme.accent)
        .imageScale(.small)
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onChange(of: cleanerEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onChange(of: wallpapersEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onAppear {
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
    }

    private var compactLayout: some View {
        TabView(selection: tabSelection) {
            ForEach(featureVisibility.visibleSections) { section in
                sectionContent(section)
                    .tabItem {
                        CompactTabLabel(
                            title: language.text(section.titleKey),
                            systemImage: section.systemImage
                        )
                    }
                    .tag(section.rawValue)
            }
        }
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                ForEach(featureVisibility.visibleSections) { section in
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) {
                            tabNavigation.select(section.rawValue)
                        }
                    } label: {
                        Label(language.text(section.titleKey), systemImage: section.systemImage)
                            .fontWeight(section.rawValue == tabNavigation.selectedTab ? .semibold : .regular)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(
                        section.rawValue == tabNavigation.selectedTab
                            ? AppTheme.accent.opacity(0.14)
                            : Color.clear
                    )
                    .accessibilityAddTraits(
                        section.rawValue == tabNavigation.selectedTab ? .isSelected : []
                    )
                }
            }
            .navigationTitle("NEXTRA PRO")
            .navigationSplitViewColumnWidth(min: 210, ideal: 240, max: 300)
        } detail: {
            sectionContent(selectedVisibleSection)
                .id(selectedVisibleSection.rawValue)
        }
        .navigationSplitViewStyle(.balanced)
    }

    @ViewBuilder
    private func sectionContent(_ section: AppSection) -> some View {
        switch section {
        case .home:
            DashboardView(
                cleanerEnabled: $cleanerEnabled,
                wallpapersEnabled: $wallpapersEnabled,
                wallpapersSupported: wallpapersSupported
            )
        case .files:
            AppDataBrowserView(
                tabSession: filesTabSession
            )
        case .patches:
            PatchProjectsView()
        case .cleaner:
            CleanerView()
        case .wallpapers:
            WallpaperLabView()
        }
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { tabNavigation.selectedTab },
            set: { tabNavigation.select($0) }
        )
    }

    private var filesTabSession: Binding<FilesTabSession> {
        Binding(
            get: { tabNavigation.filesTabs },
            set: { tabNavigation.setFilesTabs($0) }
        )
    }

    private var featureVisibility: FeatureVisibility {
        FeatureVisibility(
            cleanerEnabled: cleanerEnabled,
            wallpapersEnabled: wallpapersEnabled,
            wallpapersSupported: wallpapersSupported
        )
    }

    private var wallpapersSupported: Bool {
        WallpaperFeatureSupportPolicy.isSupported(major: AppInfo.versionTuple.major)
    }

    private var selectedVisibleSection: AppSection {
        guard let section = AppSection(rawValue: tabNavigation.selectedTab),
              featureVisibility.isVisible(section) else {
            return .home
        }
        return section
    }
}

private struct CompactTabLabel: View {
    let title: String
    let systemImage: String

    @ViewBuilder
    var body: some View {
        if let image = UIImage(
            systemName: systemImage,
            withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .medium)
        )?.withRenderingMode(.alwaysTemplate) {
            Image(uiImage: image)
        } else {
            Image(systemName: systemImage)
                .font(.system(size: 17, weight: .medium))
        }
        Text(title)
    }
}

private extension AppSection {
    var titleKey: String {
        switch self {
        case .home: return "tab.home"
        case .files: return "tab.files"
        case .patches: return "tab.patches"
        case .cleaner: return "tab.cleaner"
        case .wallpapers: return "tab.wallpapers"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .files: return "folder.fill"
        case .patches: return "shippingbox.fill"
        case .cleaner: return "sparkles"
        case .wallpapers: return "photo.on.rectangle.angled"
        }
    }
}

private struct DashboardView: View {
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @State private var showLogs = false
    @State private var selectedGame: GameTarget?
    @Binding var cleanerEnabled: Bool
    @Binding var wallpapersEnabled: Bool
    let wallpapersSupported: Bool

    private let homeAccent = AppTheme.accent
    private let homeBackground = Color(red: 0.01, green: 0.02, blue: 0.055)

    var body: some View {
        NavigationStack {
            ScrollView(.vertical, showsIndicators: false) {
                VStack(spacing: 16) {
                    headerCard
                    supportedGamesSection
                    quickActionsSection
                    featureSection
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
            }
            .background(homeBackground.ignoresSafeArea())
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showLogs = true } label: {
                        Image(systemName: "clock.arrow.circlepath")
                            .foregroundStyle(.white)
                    }
                    .accessibilityLabel(language.text("accessibility.open_logs"))
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showSettings = true } label: {
                        Image(systemName: "gearshape.fill")
                            .foregroundStyle(.white)
                    }
                    .accessibilityLabel(language.text("accessibility.open_settings"))
                }
            }
            .toolbarBackground(homeBackground, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .sheet(isPresented: $showSettings) { SettingsView() }
            .sheet(isPresented: $showLogs) { LogView() }
            .navigationDestination(item: $selectedGame) { game in
                GamePatchDetailView(game: game)
            }
        }
    }

    private var headerCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 12) {
                AppLogo(size: 54)
                    .shadow(color: homeAccent.opacity(0.35), radius: 12)

                VStack(alignment: .leading, spacing: 2) {
                    Text("NEXTRA PRO //")
                        .font(.system(size: 12, weight: .black, design: .monospaced))
                        .tracking(2)
                        .foregroundStyle(homeAccent)
                    Text("COMMAND CENTER")
                        .font(.system(size: 12, weight: .black, design: .monospaced))
                        .tracking(2)
                        .foregroundStyle(homeAccent)
                    Text("NEXTRA PRO")
                        .font(.system(size: 28, weight: .heavy, design: .default))
                        .foregroundStyle(.white)
                    Text("CONTROL SYSTEM")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .tracking(2)
                        .foregroundStyle(homeAccent)
                }

                Spacer(minLength: 0)
            }
        }
        .padding(18)
        .background(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(Color(red: 0.015, green: 0.025, blue: 0.075))
                .overlay(
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .stroke(homeAccent.opacity(0.65), lineWidth: 1)
                )
        )
        .overlay(alignment: .top) {
            Rectangle()
                .fill(homeAccent)
                .frame(height: 2)
                .clipShape(RoundedRectangle(cornerRadius: 2))
        }
    }

    private var supportedGamesSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("เกมที่รองรับ", systemImage: "gamecontroller.fill")
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(.white)

                Spacer()

                Text("ออนไลน์")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(homeAccent)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .background(homeAccent.opacity(0.12), in: Capsule())
            }

            HStack(spacing: 12) {
                GameCard(
                    title: "Free Fire",
                    bundleID: "com.dts.freefireth",
                    accent: homeAccent,
                    action: { selectedGame = GameTarget(title: "Free Fire", bundleID: "com.dts.freefireth") }
                )

                GameCard(
                    title: "Free Fire Max",
                    bundleID: "com.dts.freefiremax",
                    accent: homeAccent,
                    badge: "MAX",
                    action: { selectedGame = GameTarget(title: "Free Fire Max", bundleID: "com.dts.freefiremax") }
                )
            }
        }
        .padding(14)
        .background(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(Color.black.opacity(0.28))
                .overlay(
                    RoundedRectangle(cornerRadius: 20, style: .continuous)
                        .stroke(homeAccent.opacity(0.25), lineWidth: 1)
                )
        )
    }

    private var quickActionsSection: some View {
        HStack(spacing: 12) {
            HomeActionButton(title: "แอป", systemImage: "gamecontroller.fill", accent: homeAccent) {
                // The game cards above are the primary app launcher on the home screen.
            }

            HomeActionButton(title: "DNS", systemImage: "shield.fill", accent: homeAccent) {
                // Reserved for the DNS operation flow.
            }
        }
    }

    private var featureSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("OPERATIONS // SELECT MODE")
                .font(.system(size: 12, weight: .black, design: .monospaced))
                .tracking(2)
                .foregroundStyle(.secondary)

            Toggle(isOn: $cleanerEnabled) {
                Label(language.text("tab.cleaner"), systemImage: "sparkles")
                    .foregroundStyle(.white)
            }
            .tint(homeAccent)

            if wallpapersSupported {
                Toggle(isOn: $wallpapersEnabled) {
                    Label(language.text("tab.wallpapers"), systemImage: "photo.on.rectangle.angled")
                        .foregroundStyle(.white)
                }
                .tint(homeAccent)
            }

            HStack {
                Text(language.text("settings.ios_version"))
                    .foregroundStyle(.secondary)
                Spacer()
                Text("\(AppInfo.osVersion) (\(AppInfo.osBuild))")
                    .font(.system(.footnote, design: .monospaced))
                    .foregroundStyle(.secondary)
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(Color.white.opacity(0.045))
        )
    }
}

private struct GameCard: View {
    let title: String
    let bundleID: String
    let accent: Color
    var badge: String?
    let action: () -> Void

    @State private var icon: UIImage?

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("TARGET GAME")
                    .font(.system(size: 11, weight: .black, design: .monospaced))
                    .tracking(1.5)
                    .foregroundStyle(accent)

                Spacer()

                if let badge {
                    Text(badge)
                        .font(.system(size: 10, weight: .black, design: .monospaced))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 7)
                        .padding(.vertical, 4)
                        .background(accent, in: RoundedRectangle(cornerRadius: 6))
                } else {
                    Image(systemName: "scope")
                        .foregroundStyle(.secondary)
                }
            }

            ZStack(alignment: .topLeading) {
                if let icon {
                    Image(uiImage: icon)
                        .resizable()
                        .scaledToFill()
                } else {
                    Image(systemName: "gamecontroller.fill")
                        .font(.system(size: 42, weight: .bold))
                        .foregroundStyle(accent)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .background(Color.black.opacity(0.35))
                }
            }
            .frame(height: 118)
            .frame(maxWidth: .infinity)
            .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))

            Text(title)
                .font(.system(size: 19, weight: .heavy))
                .foregroundStyle(.white)
                .lineLimit(1)

            Text(bundleID)
                .font(.system(size: 10, weight: .medium, design: .monospaced))
                .foregroundStyle(.secondary)
                .lineLimit(1)
                .minimumScaleFactor(0.65)

            Button(action: action) {
                Label("เปิดแอป", systemImage: "arrow.up.right")
                    .font(.system(size: 13, weight: .bold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 11)
            }
            .buttonStyle(.plain)
            .foregroundStyle(.white)
            .background(accent, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
        .padding(10)
        .frame(maxWidth: .infinity)
        .background(
            RoundedRectangle(cornerRadius: 17, style: .continuous)
                .fill(Color(red: 0.015, green: 0.03, blue: 0.085))
                .overlay(
                    RoundedRectangle(cornerRadius: 17, style: .continuous)
                        .stroke(accent.opacity(0.55), lineWidth: 1)
                )
        )
        .onAppear {
            DispatchQueue.global(qos: .utility).async {
                let loaded = iconForBundleID(bundleID)
                DispatchQueue.main.async {
                    icon = loaded
                }
            }
        }
    }
}

private struct GameTarget: Identifiable, Hashable {
    let title: String
    let bundleID: String
    var id: String { bundleID }
}

private struct GamePatchDetailView: View {
    @Environment(\.appLanguage) private var language
    let game: GameTarget

    @State private var patchEnabled = false
    @State private var isWorking = false
    @State private var package: PatchLibraryItem?
    @State private var statusMessage = "กำลังตรวจสอบแพ็คเก็ต…"
    @State private var actionAlert: PatchStoreAlert?

    private let accent = AppTheme.accent

    var body: some View {
        ZStack {
            Color(red: 0.01, green: 0.02, blue: 0.055).ignoresSafeArea()

            VStack(spacing: 18) {
                VStack(spacing: 6) {
                    Text("TARGET GAME")
                        .font(.system(size: 12, weight: .black, design: .monospaced))
                        .tracking(2)
                        .foregroundStyle(accent)
                    Text(game.title)
                        .font(.system(size: 28, weight: .heavy))
                        .foregroundStyle(.white)
                    Text(game.bundleID)
                        .font(.system(size: 11, design: .monospaced))
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.top, 18)

                VStack(spacing: 16) {
                    HStack(spacing: 14) {
                        Image(systemName: "scope")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundStyle(accent)
                            .frame(width: 54, height: 54)
                            .background(accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 15))

                        VStack(alignment: .leading, spacing: 4) {
                            Text("Body Neck Drag")
                                .font(.system(size: 20, weight: .heavy))
                                .foregroundStyle(.white)
                            Text(statusMessage)
                                .font(.caption)
                                .foregroundStyle(package == nil ? .orange : .secondary)
                        }

                        Spacer()

                        if isWorking {
                            ProgressView()
                                .tint(accent)
                        } else {
                            Toggle("", isOn: $patchEnabled)
                                .labelsHidden()
                                .tint(accent)
                                .disabled(package == nil)
                                .onChange(of: patchEnabled) { enabled in
                                    handleToggle(enabled)
                                }
                        }
                    }

                    Divider().overlay(Color.white.opacity(0.08))

                    Text("เปิด = Patch ทันที • ปิด = Restore")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(18)
                .background(
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .fill(Color.black.opacity(0.28))
                        .overlay(
                            RoundedRectangle(cornerRadius: 22, style: .continuous)
                                .stroke(accent.opacity(0.45), lineWidth: 1)
                        )
                )

                Spacer()
            }
            .padding(16)
        }
        .navigationTitle(game.title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(Color(red: 0.01, green: 0.02, blue: 0.055), for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .alert(item: $actionAlert) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(alert.message(language: language)),
                dismissButton: .default(Text(language.text("common.ok")))
            )
        }
        .task {
            loadPackage()
        }
    }

    private func loadPackage() {
        let items = PatchProjectLibrary.load()
        package = items.first { item in
            guard let project = item.project else { return false }
            return project.allBundleIdentifiers.contains(game.bundleID)
                && project.name.localizedCaseInsensitiveContains("Body Neck Drag")
        }

        if let package {
            patchEnabled = DevicePatchService.latestReceipt(projectID: package.id) != nil
            statusMessage = "แพ็คเก็ตพร้อมใช้งาน"
        } else {
            patchEnabled = false
            statusMessage = "แพ็คเก็ตไม่พร้อมใช้งาน"
        }
    }

    private func handleToggle(_ enabled: Bool) {
        guard !isWorking else { return }
        guard let package, let baseProject = package.project else {
            patchEnabled = false
            statusMessage = "แพ็คเก็ตไม่พร้อมใช้งาน"
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: "patch.error.invalid_project"
            )
            return
        }

        if enabled {
            apply(package: package, project: baseProject)
        } else {
            guard let receipt = DevicePatchService.latestReceipt(projectID: package.id) else {
                statusMessage = "ยังไม่มี Patch ที่ใช้งานอยู่"
                return
            }
            restore(receipt: receipt)
        }
    }

    private func apply(package: PatchLibraryItem, project baseProject: PatchProject) {
        isWorking = true
        statusMessage = "กำลัง Patch…"
        Task.detached(priority: .userInitiated) {
            do {
                let project = package.summary.schemaVersion >= 2
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: package)
                    : baseProject
                _ = try DevicePatchService.apply(project: project)
                await MainActor.run {
                    isWorking = false
                    patchEnabled = true
                    statusMessage = "Patch สำเร็จ • พร้อมใช้งาน"
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.applied_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    patchEnabled = false
                    statusMessage = "แพ็คเก็ตไม่พร้อมใช้งาน"
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    patchEnabled = false
                    statusMessage = "แพ็คเก็ตไม่พร้อมใช้งาน"
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.apply")
                }
            }
        }
    }

    private func restore(receipt: PatchTransactionReceipt) {
        isWorking = true
        statusMessage = "กำลัง Restore…"
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(receipt: receipt)
                await MainActor.run {
                    isWorking = false
                    patchEnabled = false
                    statusMessage = "Restore สำเร็จ"
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.restored_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    patchEnabled = true
                    statusMessage = "Restore ไม่สำเร็จ"
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    patchEnabled = true
                    statusMessage = "Restore ไม่สำเร็จ"
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.restore")
                }
            }
        }
    }
}

private struct HomeActionButton: View {
    let title: String
    let systemImage: String
    let accent: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Image(systemName: systemImage)
                    .font(.system(size: 23, weight: .bold))
                Text(title)
                    .font(.system(size: 14, weight: .bold))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .foregroundStyle(.white)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(Color.white.opacity(0.045))
                    .overlay(
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .stroke(accent.opacity(0.35), lineWidth: 1)
                    )
            )
        }
        .buttonStyle(.plain)
    }
}

